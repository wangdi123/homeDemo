//
//  ViewController.m
//  新版首页demo
//
//  Created by 刘哲 on 2017/12/28.
//  Copyright © 2017年 刘哲. All rights reserved.
//

#import "ViewController.h"
#import "SegmentView.h"
#import "ScrollPageView.h"
#import "firstview.h"
#import "CollectCell.h"

#import "WGTableViewController.h"

#define iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)


#define  StatusBarAndNavigationBarHeight  (iPhoneX ? 88.0f : 20.0f)

#define WGMenuViewHeight  40.0f

#define WGHeaderViewHeight  290.f

#define SCREENW [UIScreen mainScreen].bounds.size.width
#define SCREENH [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property(nonatomic,strong)UITableView *homeTable;
@property(nonatomic,strong)UIView *headerView;
@property(nonatomic,strong)SegmentView *segmentView;
@property(nonatomic,strong)ScrollPageView *pageView;

@property (nonatomic, strong) NSArray *musicCategories;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatHeaderview];
    self.navigationController.navigationBar.hidden=YES;
    self.titleSizeNormal = 16;
    self.titleSizeSelected = 16;
    self.menuViewStyle = WMMenuViewStyleLine;
    self.menuItemWidth = [UIScreen mainScreen].bounds.size.width / self.musicCategories.count;
    self.titleColorSelected = [UIColor colorWithRed:0.4 green:0.8 blue:0.1 alpha:1.0];
    self.titleColorNormal = [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0];
    self.progressWidth=[UIScreen mainScreen].bounds.size.width / self.musicCategories.count-40;
    self.menuViewHeight = WGMenuViewHeight;
    self.headerViewHeight = WGHeaderViewHeight;
    self.minimumTopInset = StatusBarAndNavigationBarHeight;
    
}
-(void)creatHeaderview
{
    UIView *redView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, WGHeaderViewHeight)];
    redView.backgroundColor = [UIColor orangeColor];
    
    UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREENW, 180)];
    img.image=[UIImage imageNamed:@"122.jpg"];
    [redView addSubview:img];
     UICollectionViewFlowLayout *customLayout = [[UICollectionViewFlowLayout alloc] init]; // 自定义的布局对象
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 180, SCREENW, 100) collectionViewLayout:customLayout];
    collectionView.backgroundColor = [UIColor clearColor];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    [redView addSubview:collectionView];
    
    // 注册cell、sectionHeader、sectionFooter
    [collectionView registerClass:[CollectCell class] forCellWithReuseIdentifier:@"collectid"];
    
//    [collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"footerId"];
    [self.view addSubview:redView];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 4;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"collectid" forIndexPath:indexPath];
    
    
    
    cell.backgroundColor = [UIColor clearColor];
    
    return cell;
}

// 和UITableView类似，UICollectionView也可设置段头段尾
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    
       if([kind isEqualToString:UICollectionElementKindSectionFooter])
    {
        UICollectionReusableView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"footerId" forIndexPath:indexPath];
        if(footerView == nil)
        {
            footerView = [[UICollectionReusableView alloc] init];
        }
        footerView.backgroundColor = [UIColor lightGrayColor];
        
        return footerView;
    }
    
    return nil;
}
//header高度

//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFootererInSection:(NSInteger)section{
//
//        return CGSizeMake(SCREENW, 10);
//
//}
//调节item边距

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    
    
    return UIEdgeInsetsMake(5, 5, 0, 5);
    
}
//item大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{

        return CGSizeMake((SCREENW - 45)/4, 90);
}

#pragma mark - Datasource & Delegate
- (NSInteger)numbersOfChildControllersInPageController:(WMPageController *)pageController {
    return self.musicCategories.count;
}

- (UIViewController *)pageController:(WMPageController *)pageController viewControllerAtIndex:(NSInteger)index {
    switch (index) {
        case 0:
            return [WGTableViewController new];
        case 1:{
            return [WGTableViewController new];
        }
        default:
            return [UIViewController new];
    }
}

- (NSString *)pageController:(WMPageController *)pageController titleAtIndex:(NSInteger)index {
    return self.musicCategories[index];
}

#pragma mark - lazy
- (NSArray *)musicCategories {
    if (!_musicCategories) {
        _musicCategories = @[@"同城", @"社群", @"关注",@"视频",@"广告"];
    }
    return _musicCategories;
}


@end
