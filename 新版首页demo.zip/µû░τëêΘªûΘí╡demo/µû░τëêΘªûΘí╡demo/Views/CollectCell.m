//
//  CollectCell.m
//  新版首页demo
//
//  Created by 刘哲 on 2017/12/28.
//  Copyright © 2017年 刘哲. All rights reserved.
//

#import "CollectCell.h"

@implementation CollectCell

#define cellwidth self.frame.size.width
#define cellheight self.frame.size.height
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        _iconImg=[[UIImageView alloc]initWithFrame:CGRectMake(cellwidth/2-10, 5, 40, 40)];
        _iconImg.image=[UIImage imageNamed:@"cute.jpg"];
        _iconImg.layer.masksToBounds=YES;
        _iconImg.layer.cornerRadius=20;
        [self addSubview:_iconImg];
        
        _titleLab=[[UILabel alloc]initWithFrame:CGRectMake(cellwidth/2-25, cellheight-40, 65, 40)];
        _titleLab.textAlignment=1;
        _titleLab.text=@"同城交友";
        _titleLab.font=[UIFont systemFontOfSize:15];
        [self addSubview:_titleLab];
    }
    return self;
}
@end
