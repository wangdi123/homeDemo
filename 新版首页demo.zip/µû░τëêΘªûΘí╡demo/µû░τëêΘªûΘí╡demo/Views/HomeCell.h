//
//  HomeCell.h
//  新版首页demo
//
//  Created by 刘哲 on 2017/12/28.
//  Copyright © 2017年 刘哲. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCell : UITableViewCell

@property(nonatomic,strong)UIImageView *iconImg;
@property(nonatomic,strong)UILabel *nameLab;
@property(nonatomic,strong)UILabel *biaotiLab;
@property(nonatomic,strong)UIImageView *infoImg;
@end
