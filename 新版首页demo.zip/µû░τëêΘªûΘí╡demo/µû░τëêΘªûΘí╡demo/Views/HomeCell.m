//
//  HomeCell.m
//  新版首页demo
//
//  Created by 刘哲 on 2017/12/28.
//  Copyright © 2017年 刘哲. All rights reserved.
//

#import "HomeCell.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height

@implementation HomeCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        _iconImg=[[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 35, 35)];
        _iconImg.layer.masksToBounds=YES;
        _iconImg.layer.cornerRadius=35/2;
        _iconImg.image=[UIImage imageNamed:@"cute.jpg"];
        [self addSubview:_iconImg];
        
        _nameLab=[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_iconImg.frame)+5, 8, 45, 15)];
        _nameLab.text=@"往生";
        _nameLab.font=[UIFont systemFontOfSize:15];
        [self addSubview:_nameLab];
        _biaotiLab=[[UILabel alloc]initWithFrame:CGRectMake(5, CGRectGetMaxY(_iconImg.frame)+5, WIDTH-10, 45)];
        _biaotiLab.text=@"打了两局王者😑午饭还没吃上，啊啊啊啊啊啊等位时求超越";
        _biaotiLab.font=[UIFont systemFontOfSize:15];
        _biaotiLab.numberOfLines=0;
        [self addSubview:_biaotiLab];
        
        _infoImg=[[UIImageView alloc]initWithFrame:CGRectMake(5,CGRectGetMaxY(_biaotiLab.frame)+5, 50, 50)];
        _infoImg.image=[UIImage imageNamed:@"122.jpg"];
        [self addSubview:_infoImg];
    }
    return self;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
