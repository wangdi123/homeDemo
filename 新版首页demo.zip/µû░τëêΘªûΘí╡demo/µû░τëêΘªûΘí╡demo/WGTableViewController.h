//
//  WGTableViewController.h
//  WG例子
//
//  Created by 崔志伟 on 2017/12/28.
//  Copyright © 2017年 崔志伟. All rights reserved.
//

#import "WMStickyPageViewController.h"
@interface WGTableViewController : UITableViewController
<WMStickyPageViewControllerDelegate>

@end
