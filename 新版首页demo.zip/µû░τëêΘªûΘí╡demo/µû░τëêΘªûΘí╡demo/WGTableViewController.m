//
//  WGTableViewController.m
//  WG例子
//
//  Created by 崔志伟 on 2017/12/28.
//  Copyright © 2017年 崔志伟. All rights reserved.
//

#import "WGTableViewController.h"
#import "HomeCell.h"

static NSString *const WGTablewCellIdentifier = @"WGTablewCellIdentifier";

@interface WGTableViewController ()

@end

@implementation WGTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[HomeCell class] forCellReuseIdentifier:WGTablewCellIdentifier];
}


#pragma mark - WMStickyPageViewControllerDelegate
- (UIScrollView *)streachScrollView {
    return self.tableView;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 100;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeCell *cell = [tableView dequeueReusableCellWithIdentifier:WGTablewCellIdentifier forIndexPath:indexPath];
    return cell;
}


@end
