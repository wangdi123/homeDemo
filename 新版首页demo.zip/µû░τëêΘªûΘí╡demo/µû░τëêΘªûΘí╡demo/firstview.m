//
//  firstview.m
//  新版首页demo
//
//  Created by 刘哲 on 2017/12/28.
//  Copyright © 2017年 刘哲. All rights reserved.
//

#import "firstview.h"



@interface firstview ()<UITableViewDelegate,UITableViewDataSource>

#define SCREENW [UIScreen mainScreen].bounds.size.width
#define SCREENH [UIScreen mainScreen].bounds.size.height

@property(nonatomic,strong)UITableView *homeTable;

@end

@implementation firstview

-(UITableView *)homeTable
{
    if (!_homeTable) {
        _homeTable=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREENW, SCREENH)];
        _homeTable.delegate=self;
        _homeTable.dataSource=self;
    }
    return _homeTable;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        [self addSubview:self.homeTable];
    }
    return self;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellid"];
    }
    cell.textLabel.text=@"123";
    return cell;
}

@end
