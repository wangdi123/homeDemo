//
//  main.m
//  新版首页demo
//
//  Created by 刘哲 on 2017/12/28.
//  Copyright © 2017年 刘哲. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
